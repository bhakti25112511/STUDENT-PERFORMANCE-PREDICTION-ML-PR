@echo off
title Student Marks Prediction ML Project
echo ==========================================
echo   Student Marks Prediction - ML Project
echo ==========================================
echo.
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo During installation, tick "Add Python to PATH".
  pause
  exit /b 1
)
echo Installing required Python libraries...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Library installation failed. Check your internet connection and Python installation.
  pause
  exit /b 1
)
echo.
echo Starting the project in your browser...
python -m streamlit run app.py
pause
