# MINI-PROJECT SYNOPSIS

## Title
Student Marks Prediction Using Machine Learning

## 1. Introduction
Student academic performance is affected by several factors, including study habits and performance in earlier assessments. Machine learning can analyze historical student records and estimate a final grade. This project develops a simple Student Marks Prediction System using Linear Regression and presents predictions through a user-friendly web interface.

## 2. Problem Statement
To develop a basic machine-learning application that estimates a student's final Mathematics grade using selected information from historical student performance data.

## 3. Objectives
1. To obtain and explore a public student performance dataset.
2. To prepare relevant input features and the target grade.
3. To train a Linear Regression model.
4. To evaluate the model using MAE, RMSE and R².
5. To build a simple interface for entering student information and viewing an estimated grade.

## 4. Dataset
The application bundle includes a synthetic demonstration file (`student-mat.csv`) so the app runs offline. For a real-data submission, replace it with the Mathematics file from the UCI Student Performance dataset. The selected features are `studytime`, `G1` and `G2`; the target is `G3`. Grades use a 0–20 scale. The `studytime` field is a weekly study-time category.

## 5. Proposed Methodology
1. Load the dataset using Pandas.
2. Select the required columns and remove missing records.
3. Divide the data into 80% training and 20% testing records.
4. Train a Linear Regression model using scikit-learn.
5. Evaluate test predictions using Mean Absolute Error, Root Mean Squared Error and R².
6. Display evaluation graphs and predictions in a Streamlit application.

## 6. Software Requirements
- Python 3.10+
- Pandas and NumPy
- scikit-learn
- Matplotlib
- Streamlit
- Visual Studio Code or another Python editor

## 7. Expected Outcome
The system will display an estimated final Mathematics grade based on the input study-time category and earlier grades. It will also show model evaluation metrics, a dataset preview, summary statistics and an actual-versus-predicted graph. Actual performance metrics will be recorded after running the application.

## 8. Limitations
The model uses a limited set of features and a single baseline algorithm. Since `G1` and `G2` are earlier grades, it is intended to estimate final grade after those assessments. Predictions are not guaranteed outcomes and should not be used as the sole basis for educational decisions.

## 9. Reference
Bundled data is synthetic demonstration data, not the UCI records. If replaced with official data, cite Cortez, P. (2008), Student Performance, UCI Machine Learning Repository, https://doi.org/10.24432/C5TG7T.
Dataset: https://archive.ics.uci.edu/dataset/320/student+performance
