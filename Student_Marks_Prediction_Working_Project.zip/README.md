# Student Marks Prediction Using Machine Learning

## Quick start (Windows)
1. Extract the ZIP folder.
2. If Python is not installed, install Python 3.10+ from https://www.python.org/downloads/ and tick **Add Python to PATH**.
3. Double-click `START_PROJECT.bat`.
4. Wait for dependencies to install. The app opens at `http://localhost:8501`.
5. Keep the terminal window open while using the app.

If the app does not launch, open Command Prompt in this folder and run:
```bat
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## What's inside
- `app.py`: Streamlit web app and Linear Regression model
- `student-mat.csv`: bundled synthetic demonstration data, allowing offline app launch
- `requirements.txt`: Python dependencies
- `Student_Marks_Prediction_Synopsis.docx`: synopsis
- `Student_Marks_Prediction_Project_Report.docx`: report template

## Important data note
The included `student-mat.csv` is **synthetic demonstration data**, created so the application runs even when dataset downloads fail. It is not the original UCI student records. Before presenting this as a real-data ML project, download the official Mathematics file from https://archive.ics.uci.edu/dataset/320/student+performance and replace the bundled `student-mat.csv`. The official dataset has grades on a 0–20 scale and `studytime` is a category, not an exact hour count.

Do not claim that results from the bundled synthetic file are results from UCI. Use the metrics displayed by the app after loading the dataset you intend to report.
