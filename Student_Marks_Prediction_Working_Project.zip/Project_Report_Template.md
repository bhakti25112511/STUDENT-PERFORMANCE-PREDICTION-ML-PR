# STUDENT MARKS PREDICTION USING MACHINE LEARNING
## Mini-Project Report Template

**Student Name:** ____________________  
**Roll Number:** ____________________  
**Department:** Artificial Intelligence and Data Science  
**College:** ____________________  
**Academic Year:** ____________________

---

## Abstract
This project develops a Student Marks Prediction System using Linear Regression. It uses the Mathematics records in the UCI Student Performance dataset. The model takes weekly study-time category (`studytime`) and earlier assessment grades (`G1`, `G2`) as inputs and estimates the final grade (`G3`). The records are split into training and testing sets. Model performance is measured with MAE, RMSE and R². A Streamlit interface allows a user to enter values and view an estimated grade. The system is an educational demonstration; predictions are estimates and not guaranteed outcomes.

## 1. Introduction
Machine learning can be used to identify patterns in historical data and make estimates for new observations. In education, a model may estimate final grades from earlier assessment results and selected study information. This project demonstrates a basic regression workflow, from loading and preparing data to training, evaluation, visualization and a simple interface.

## 2. Problem Statement
To create an application that estimates a student's final Mathematics grade from selected historical student performance features using a supervised machine-learning algorithm.

## 3. Objectives
- Load and inspect a public student performance dataset.
- Select relevant features and the prediction target.
- Train a Linear Regression model.
- Evaluate the model on held-out data.
- Display predictions and evaluation graphs through a simple interface.

## 4. Dataset Description
**Bundled file:** `student-mat.csv` (synthetic demonstration data for offline testing).  
**Real-data source to use for final research:** UCI Machine Learning Repository, Student Performance dataset.  
**Input features:** `studytime`, `G1`, `G2`  
**Target:** `G3`  
Grades are on a 0–20 scale. `studytime` is a category: 1 = under 2 hours/week; 2 = 2–5 hours/week; 3 = 5–10 hours/week; 4 = over 10 hours/week.

## 5. Tools and Technologies
- Python
- Pandas and NumPy
- scikit-learn
- Matplotlib
- Streamlit

## 6. Methodology
1. Load the UCI Mathematics dataset.
2. Keep the selected columns and convert them to numeric values.
3. Remove incomplete records in the selected columns.
4. Split records into 80% training and 20% testing data using a fixed random seed.
5. Fit a Linear Regression model on the training data.
6. Predict final grades for the test records.
7. Calculate MAE, RMSE and R².
8. Display model results and allow sample predictions in the Streamlit interface.

## 7. Algorithm: Linear Regression
Linear Regression models a numerical target as a linear combination of input features:

`ŷ = b₀ + b₁x₁ + b₂x₂ + ... + bₙxₙ`

Here, the target is `G3`, and the features are `studytime`, `G1` and `G2`. The model learns coefficients from the training data and uses them to estimate grades for unseen records.

## 8. Evaluation Metrics
- **MAE:** average absolute difference between actual and predicted grades.
- **RMSE:** square root of average squared prediction error; larger errors receive more weight.
- **R²:** measures fit relative to predicting the test-set mean; it can be negative.

### Results
Fill this table with values from your actual run. Do not invent results.

| Metric | Value from your run |
|---|---|
| MAE | __________________ |
| RMSE | __________________ |
| R² | __________________ |

## 9. Application Modules
1. **Predict Marks:** input study-time category and earlier grades; display estimated final grade.
2. **Model Performance:** display MAE, RMSE, R² and actual-versus-predicted graph.
3. **Explore Dataset:** display sample rows, final-grade distribution and summary statistics.
4. **About Project:** describe methodology, dataset and limitations.

## 10. Results and Discussion
After running the application, insert screenshots of the prediction page, evaluation metrics, actual-versus-predicted graph and dataset preview. Discuss the actual MAE, RMSE and R² values from your run. Performance should be interpreted cautiously because it depends on the dataset, selected features and train/test split.

## 11. Limitations
- Only three input features are used.
- Only Linear Regression is implemented as the main model.
- Earlier grades (`G1`, `G2`) are included, so this model is not an early-term prediction based only on study habits.
- The dataset uses grades from 0 to 20.
- Predictions are estimates, not guarantees, and should not be used as the sole basis for decisions about students.

## 12. Future Scope
- Compare Linear Regression with Decision Tree and Random Forest regression.
- Test more features and use cross-validation.
- Improve input validation and the user interface.
- Evaluate fairness and generalization before any real-world use.

## 13. Conclusion
The project demonstrates an end-to-end supervised machine-learning workflow for estimating student final grades. It includes dataset preparation, model training, evaluation and an interactive interface. The actual metrics obtained from the completed run should be reported. The application is a learning prototype rather than a guaranteed predictor of individual academic outcomes.

## 14. References
Bundled data is synthetic demonstration data, not the UCI records. If replaced with official data, cite: Cortez, P. (2008). *Student Performance*. UCI Machine Learning Repository. https://doi.org/10.24432/C5TG7T  
Dataset page: https://archive.ics.uci.edu/dataset/320/student+performance
